
public class Zbran {
	public String jmeno;
	public int sila;
	public int dmg;
	
	public Zbran(String jm, int str, int ouch) 
	{
		jmeno = jm;
		sila = str;
		dmg = ouch;
	}
	public Zbran() 
	{
		jmeno = "remdih";
		sila = 20;
		dmg = 30;
	}
	
}
